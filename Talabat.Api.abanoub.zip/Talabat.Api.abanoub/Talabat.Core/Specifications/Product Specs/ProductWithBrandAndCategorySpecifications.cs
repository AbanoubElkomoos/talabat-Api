﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Talabat.Core.Entities;

namespace Talabat.Core.Specifications.Product_Specs
{
	public class ProductWithBrandAndCategorySpecifications: BaseSpecifications<Product>
	{
        public ProductWithBrandAndCategorySpecifications(ProductSpecParams spec)
            :base( p =>
            ( string.IsNullOrEmpty (spec.Search) || p.Name.ToLower().Contains(spec.Search.ToLower()))&&
            (!spec.BrandId.HasValue || p.BrandId == spec.BrandId.Value) 
            && 
            (!spec.CategoryId.HasValue || p.CategoryId == spec.CategoryId.Value)  )
        {
            // this Constructor Will Be Used Creating Object for Get All Products 
            Includes.Add(P => P.Brand);
            Includes.Add(P => P.Category);


            if (!string.IsNullOrEmpty(spec.Sort))
            {

                switch (spec.Sort)
                {
                    case "PriceAsc":
                        AddOrderBy(P => P.Price);
                        break;

                    case "PriceDesc":
                        AddOrderByDesc(P => P.Price);
                        break;

                    default:
                        AddOrderBy(P => P.Name);
                        break;

                }
            }
            else
            {

                AddOrderBy(P => P.Name);

            }

            ApplyPagination((spec.PageIndex - 1) * spec.PageSize, spec.PageSize);
        }

		public ProductWithBrandAndCategorySpecifications(int id) : base(P => P.Id == id)
		{
            Includes.Add(P => P.Brand);
            Includes.Add(P => P.Category);
        }

		
	}
}
