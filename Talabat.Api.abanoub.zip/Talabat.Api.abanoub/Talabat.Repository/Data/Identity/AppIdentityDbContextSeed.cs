﻿using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using Talabat.Core.Entities;
using Talabat.Core.Entities.Identity;

namespace Talabat.Infrastructure.Data.Identity
{
    public class AppIdentityDbContextSeed
    {
        public static async Task SeedUsersAsync (UserManager<AppUser> _userManager)
        {

            if (_userManager.Users.Count() == 0)
            {

                var user = new AppUser()
                {

                    DisplayName = "Abanoub Elkomoos",
                    Email = "abanoubelkomoos@gmail.com",
                    UserName = "abanoubelkomoos",
                    PhoneNumber = "01021233995"

                };

                await _userManager.CreateAsync(user,"Pa$$w0rd");
            }

        }
    }
}
