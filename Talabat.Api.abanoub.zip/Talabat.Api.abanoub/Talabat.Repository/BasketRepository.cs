﻿using StackExchange.Redis;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using Talabat.Core.Entities;
using Talabat.Core.Repositories.Contract;

namespace Talabat.Infrastructure
{
    public class BasketRepository : IBasketRepository
    {
        private readonly IDatabase _datebase;

        public BasketRepository(IConnectionMultiplexer redis) 
        {
            _datebase = redis.GetDatabase();
        }
        public async Task<bool> DeleteBasketAsynk(string basketId)
        {
            return await _datebase.KeyDeleteAsync(basketId);
        }

        public async Task<CustomerBasket?> GetBasketAsync(string basketId)
        {
            var basket = await _datebase.StringGetAsync(basketId);
            return basket.IsNullOrEmpty ? null : JsonSerializer.Deserialize<CustomerBasket>(basket);
        }

        public async Task<CustomerBasket> UpdateBasketAsync(CustomerBasket basket)
        {
            var CreatedOrUpdate = await _datebase.StringSetAsync(basket.Id, JsonSerializer.Serialize(basket), TimeSpan.FromDays(30));
            if (CreatedOrUpdate is false) return null;

            return await GetBasketAsync(basket.Id);
        }
    }
}
