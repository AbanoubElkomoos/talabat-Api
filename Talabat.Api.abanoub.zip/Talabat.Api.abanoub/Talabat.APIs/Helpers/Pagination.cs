﻿using Talabat.APIs.Dtos;

namespace Talabat.APIs.Helpers
{
    public class Pagination<T>
    {
        

        public int PageSize { get; set; }

        public int PageIndex { get; set; }

        public int Count { get; set; }

        public IReadOnlyList<T> Date { get; set; }


        public Pagination(int pageIndex, int pageSize, int count, IReadOnlyList<T> date)
        {
            PageIndex = pageIndex;
            PageSize = pageSize;
            Date = date;
            Count = count;
        }


    }
}
