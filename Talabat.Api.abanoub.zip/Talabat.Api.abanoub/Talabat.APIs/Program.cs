using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using StackExchange.Redis;
using System.Net;
using System.Text;
using System.Text.Json;
using Talabat.APIs.Errors;
using Talabat.APIs.Extensions;
using Talabat.APIs.Helpers;
using Talabat.APIs.Middlewares;
using Talabat.Core.Entities;
using Talabat.Core.Entities.Identity;
using Talabat.Core.Repositories.Contract;
using Talabat.Core.Services.Contract;
using Talabat.Infrastructure.Data.Identity;
using Talabat.Repository;
using Talabat.Repository.Data;
using Talabat.ServicesLayer.AuthService;

namespace Talabat.APIs
{
	public class Program
	{
		public static async Task Main(string[] args)
		{
			var builder = WebApplication.CreateBuilder(args);

			#region Configure Services
			
			// Add services to the container.

			builder.Services.AddControllers();

			builder.Services.AddSwaggerServices();

			builder.Services.AddDbContext<StoreContext>(options =>
			{
				options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection"));
			});


            builder.Services.AddDbContext<AppIdentityDbContext>(optionBuilder =>
            {
                optionBuilder.UseSqlServer(builder.Configuration.GetConnectionString("IdentityConnection"));
            });

            //builder.Services.AddScoped<IGenericRepository<Product>, GenericRepository<Product>>();
            //builder.Services.AddScoped<IGenericRepository<ProductBrand>, GenericRepository<ProductBrand>>();
            //builder.Services.AddScoped<IGenericRepository<ProductCategory>, GenericRepository<ProductCategory>>();


            builder.Services.AddSingleton<IConnectionMultiplexer>((ServiceProvider) =>
			{
				var connection = builder.Configuration.GetConnectionString("Redis");
				return ConnectionMultiplexer.Connect(connection);

			});
		
			builder.Services.AddAplicationServices();


			builder.Services.AddIdentity<AppUser, IdentityRole>(Options =>
			{

			}).AddEntityFrameworkStores<AppIdentityDbContext>();



			builder.Services.AddAuthentication(options=>
			{
				options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
				options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;

            }
			).AddJwtBearer( /*JwtBearerDefaults.AuthenticationScheme*/  options =>
			{
				options.TokenValidationParameters = new TokenValidationParameters()
				{
					ValidateIssuer = true,
                    ValidIssuer = builder.Configuration["JWT:ValidIssuer"],
					ValidateAudience = true,
                    ValidAudience = builder.Configuration["JWT:ValidAudience"],
					ValidateLifetime = true,
					ClockSkew = TimeSpan.Zero,
					ValidateIssuerSigningKey = true,
                    IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(builder.Configuration["JWT:AuthKey"] ?? string.Empty ))
                };
			});

			builder.Services.AddScoped(typeof(IAuthService) , typeof(AuthService));

			#endregion

			var app = builder.Build();

			using var scope = app.Services.CreateScope();

		    var services = scope.ServiceProvider;

		    var _dbContext = services.GetRequiredService<StoreContext>();

			var _identityDbContext = services.GetRequiredService<AppIdentityDbContext>();

			var loggerFactory = services.GetRequiredService<ILoggerFactory>();
			var _logger = loggerFactory.CreateLogger<Program>();

			try
			{
				await _dbContext.Database.MigrateAsync();
				await StoreContextSeed.SeedAsync(_dbContext);

				await _identityDbContext.Database.MigrateAsync(); // update-Datebase

				var _userManager = services.GetRequiredService<UserManager<AppUser>>();
				await AppIdentityDbContextSeed.SeedUsersAsync(_userManager);

            }
			catch (Exception ex)
			{
                _logger.LogError(ex.StackTrace.ToString());
            }


			#region Configure Kestrel Middlewares

			app.UseMiddleware<ExceptionMiddleware>();

			#region MiddleWare another way
	//		app.Use(async (httpContext, _next) =>
	//{
	//	try
	//	{
	//		//writing code that takes action with the Request

	//		await _next.Invoke(httpContext); //Go to the next Middleware

	//		//writing code that takes action with the Response
	//	}
	//	catch (Exception ex)
	//	{
	//		_logger.LogError(ex.Message);

	//		httpContext.Response.StatusCode = (int)HttpStatusCode.InternalServerError;
	//		httpContext.Response.ContentType = "application/json";

	//		var response = app.Environment.IsDevelopment() ?
	//			new ApiExceptionResponse((int)HttpStatusCode.InternalServerError, ex.Message, ex.StackTrace.ToString())
	//			:
	//			new ApiExceptionResponse((int)HttpStatusCode.InternalServerError);

	//		var options = new JsonSerializerOptions() { PropertyNamingPolicy = JsonNamingPolicy.CamelCase };

	//		var json = JsonSerializer.Serialize(response, options);

	//		await httpContext.Response.WriteAsync(json);

	//	}
	//}); 
			#endregion


			// Configure the HTTP request pipeline.
			if (app.Environment.IsDevelopment())
			{
				app.UseSwaggerMiddlewares();
			}

			app.UseStatusCodePagesWithReExecute("/Errors");

			app.UseHttpsRedirection();

			app.UseStaticFiles();

			app.UseAuthorization();


			app.UseAuthentication();



            //app.UseAuthorization();
            app.MapControllers();

            #endregion

            app.Run();
		}
	}
}
